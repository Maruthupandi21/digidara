from flask import Flask, render_template, request, redirect,session, url_for
import mysql.connector

app = Flask(__name__)


# 🔧 MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DATABASE'] = 'admine'

# Connect to MySQL using app.config
db = mysql.connector.connect(
    host=app.config['MYSQL_HOST'],
    user=app.config['MYSQL_USER'],
    password=app.config['MYSQL_PASSWORD'],
    database=app.config['MYSQL_DATABASE']
)
cursor = db.cursor(dictionary=True)

@app.route('/')
@app.route('/home')
def home():
    return render_template("home.html")
@app.route('/notice2')
def notice2():
    cursor.execute("SELECT * FROM notices ORDER BY created_at DESC")
    notices = cursor.fetchall()
    return render_template("notice2.html", notices=notices)
    

@app.route('/admin', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        admin_id = request.form['admin_id']
        password = request.form['password']
        cursor.execute("SELECT * FROM admins WHERE admin_id=%s AND password=%s", (admin_id, password))
        admin = cursor.fetchone()
        if admin:
            session['admin'] = admin['admin_id']
            return redirect(url_for('post1'))
        else:
            return "Invalid credentials"
    return render_template("admin.html")

@app.route('/login', methods=['GET', 'POST'])
def student_login():
    if request.method == 'POST':
        regno = request.form['regno']
        dept = request.form['department']
        year = request.form['year']
        session['student'] = regno
        return redirect(url_for('home'))
    return render_template("login.html")

@app.route('/post1', methods=['GET', 'POST'])
def post_notice():
    if 'admin' not in session:
        return redirect(url_for('admin'))

    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        posted_by = session['admin']
        cursor.execute("INSERT INTO notices (title, content, posted_by) VALUES (%s, %s, %s)",
                       (title, content, posted_by))
        db.commit()
        return redirect(url_for('home'))

    return render_template("post1.html")

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
